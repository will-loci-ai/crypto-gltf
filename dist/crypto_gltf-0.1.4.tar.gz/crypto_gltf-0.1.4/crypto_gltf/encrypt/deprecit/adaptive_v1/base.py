from crypto_gltf.encrypt.base import BaseCryptoSystem


class AdaptiveBaseModel(BaseCryptoSystem):
    """Base model for adaptive encryption/decryption model"""

    AAD: bool = True
