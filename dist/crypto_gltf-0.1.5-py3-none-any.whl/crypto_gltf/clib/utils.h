#include <stdio.h>
#include <stdint.h>

uint32_t slice32(uint32_t num, size_t start, size_t stop);
uint8_t slice8(uint8_t num, size_t start, size_t stop);
